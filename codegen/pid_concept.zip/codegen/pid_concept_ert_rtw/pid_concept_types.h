/*
 * File: pid_concept_types.h
 *
 * Code generated for Simulink model 'pid_concept'.
 *
 * Model version                  : 1.1
 * Simulink Coder version         : 9.4 (R2020b) 29-Jul-2020
 * C/C++ source code generated on : Thu Mar 24 15:31:41 2022
 *
 * Target selection: ert.tlc
 * Embedded hardware selection: Custom Processor->Custom Processor
 * Code generation objectives: Unspecified
 * Validation result: Not run
 */

#ifndef RTW_HEADER_pid_concept_types_h_
#define RTW_HEADER_pid_concept_types_h_

/* Model Code Variants */

/* Forward declaration for rtModel */
typedef struct tag_RTM_pid_concept_T RT_MODEL_pid_concept_T;

#endif                                 /* RTW_HEADER_pid_concept_types_h_ */

/*
 * File trailer for generated code.
 *
 * [EOF]
 */
