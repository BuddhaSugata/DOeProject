/*
 * File: untitled_data.c
 *
 * Code generated for Simulink model 'untitled'.
 *
 * Model version                  : 1.0
 * Simulink Coder version         : 9.4 (R2020b) 29-Jul-2020
 * C/C++ source code generated on : Thu Mar 24 15:44:14 2022
 *
 * Target selection: ert.tlc
 * Embedded hardware selection: Intel->x86-64 (Windows64)
 * Code generation objectives: Unspecified
 * Validation result: Not run
 */

#include "untitled.h"
#include "untitled_private.h"

/* Constant parameters (default storage) */
const ConstP_untitled_T untitled_ConstP = {
  /* Computed Parameter: Internal_A
   * Referenced by: '<S1>/Internal'
   */
  { -50.0, 1.0, -50.0, 1.0, -50.0, 1.0, -50.0, 1.0, -50.0, 1.0, -50.0, 1.0,
    -50.0, 1.0, -50.0, 1.0, -50.0, 1.0, -50.0 }
};

/*
 * File trailer for generated code.
 *
 * [EOF]
 */
